package com.hcl.tokbox;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SessionInfo {

	private String room_name;

	@JsonProperty("room_name")
	public String getRoom_name() {
		return room_name;
	}

	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}

	@JsonProperty("session_id")
	public String getSession_id() {
		return session_id;
	}

	public void setSession_id(String session_id) {
		this.session_id = session_id;
	}

	private String session_id;

	public SessionInfo() {

	}

	public SessionInfo(String room_name, String session_id) {
		this.room_name = room_name;
		this.session_id = session_id;

	}

}
