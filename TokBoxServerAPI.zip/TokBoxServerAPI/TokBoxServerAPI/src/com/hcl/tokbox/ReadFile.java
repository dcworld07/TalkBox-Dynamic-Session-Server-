package com.hcl.tokbox;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ReadFile {
	public JSONArray readSessionIdFromFile() {
		JSONArray array = null;
		JSONParser parser = new JSONParser();
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("SessionStore.json").getFile());
			array = (JSONArray) parser.parse(new FileReader(file));
			for (int i = 0; i < array.size(); i++) {
				JSONObject jsonOBJ = (JSONObject) array.get(i);
				String name = (String) jsonOBJ.get("room_name");
				String sessionId = (String) jsonOBJ.get("session_id");
			}
		} catch (Exception e) {
			System.out.println("=======" + e.toString());
		}
		
		return array;

	}
	public void writeJson(JSONArray jsonObject) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
			File file = new File(classLoader.getResource("SessionStore.json").getFile());
				FileWriter filew = new FileWriter(file);
				filew.write(jsonObject.toJSONString());
				filew.flush();
				filew.close();
		} catch (Exception e) {
			System.out.println("=======" + e.toString());
		}

	}
	
	public String isRoomAlreadyExist(String roomName) {
		String _sessionId="";
		JSONArray array=readSessionIdFromFile();
		for (int i = 0; i < array.size(); i++) {
			JSONObject jsonOBJ = (JSONObject) array.get(i);
			String name = (String) jsonOBJ.get("room_name");
			if(name.equalsIgnoreCase(roomName)){
				_sessionId = (String) jsonOBJ.get("session_id");
			}
		}
		return _sessionId;
	}

	public static void main(String[] args) {
		ReadFile file = new ReadFile();
		String id=file.isRoomAlreadyExist("RaVi");
		System.out.println("==+++=====" + id);
//		JSONArray jsonOBJ=file.readSessionIdFromFile();
//		System.out.println("=======" + jsonOBJ.toString());
//		JSONObject obj1 = new JSONObject();
//		obj1.put("room_name", "deepak");
//		obj1.put("session_id", "kjbsabsahbf");
//		JSONObject obj2 = new JSONObject();
//		obj2.put("room_name", "deepansu");
//		obj2.put("session_id", "123444");
//		jsonOBJ.add(obj1);
//		jsonOBJ.add(obj2);
//		file.writeJson(jsonOBJ);
//		System.out.println("==+++=====" + file.readSessionIdFromFile());
	}
}
