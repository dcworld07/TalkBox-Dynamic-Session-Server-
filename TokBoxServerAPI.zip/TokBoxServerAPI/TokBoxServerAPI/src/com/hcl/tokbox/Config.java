package com.hcl.tokbox;

public class Config {

	public static final String apiSecret="78b0a53ab4b7f1691eb50bc85f9d90a909fca212";
	public static final int apiKey=45615232;
}
