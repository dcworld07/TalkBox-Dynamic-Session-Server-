package com.hcl.tokbox;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.json.JSONObject;
import org.json.simple.JSONArray;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opentok.MediaMode;
import com.opentok.OpenTok;
import com.opentok.Role;
import com.opentok.Session;
import com.opentok.SessionProperties;
import com.opentok.TokenOptions;
import com.opentok.exception.OpenTokException;

@Path("/getSession")
public class GetSession {
	@SuppressWarnings("unchecked")
	@POST
	@Produces("application/json")
	public Response createOpenTokSession(InputStream customer) {
		String mRoomName = "";
		int httpErrorCode = 200;
		/******************** Params Get ***************************/
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(customer));
			String line = null;
			while ((line = in.readLine()) != null) {
				stringBuilder.append(line);
			}
		} catch (Exception e) {
		}
		try {
			SessionInfo agentInfo = (SessionInfo) new ObjectMapper().readValue(stringBuilder.toString(), SessionInfo.class);
			mRoomName = agentInfo.getRoom_name();
		} catch (IOException e) {
		}

		/**********************************************/
		try {
			ReadFile readFile = new ReadFile();
			String _sessionId = readFile.isRoomAlreadyExist(mRoomName);
			OpenTok opentok = new OpenTok(Config.apiKey, Config.apiSecret);
			Session session = null;
			String token = null;
			JSONObject jsonObject = new JSONObject();
			if (_sessionId != null && !_sessionId.equalsIgnoreCase("")) {
				session = opentok.createSession(new SessionProperties.Builder().mediaMode(MediaMode.ROUTED).build());
				token = opentok.generateToken(_sessionId, new TokenOptions.Builder().role(Role.PUBLISHER)
						.expireTime((System.currentTimeMillis() / 1000L) + (3 * 60 * 60)).build());
				jsonObject.put("Status", "1");
				jsonObject.put("Session", _sessionId);
				jsonObject.put("token", token);
				jsonObject.put("Message", "Connected");
			} else {
				session = opentok.createSession(new SessionProperties.Builder().mediaMode(MediaMode.ROUTED).build());
				String msessionId = session.getSessionId();
				token = opentok.generateToken(msessionId, new TokenOptions.Builder().role(Role.PUBLISHER)
						.expireTime((System.currentTimeMillis() / 1000L) + (3 * 60 * 60)).build());

				if (msessionId != null && !msessionId.equalsIgnoreCase("")) {
					JSONArray jsonArr = readFile.readSessionIdFromFile();
					JSONObject obj1 = new JSONObject();
					obj1.put("room_name", mRoomName);
					obj1.put("session_id", msessionId);
					jsonArr.add(obj1);
					readFile.writeJson(jsonArr);
					jsonObject.put("Status", "1");
					jsonObject.put("Session", msessionId);
					jsonObject.put("token", token);
					jsonObject.put("Message", "Connected");
				}

			}

			String result = jsonObject.toString();

			return Response.status(200).entity(result).build();

		} catch (OpenTokException e1) {
			System.out.println("Exception" + e1.getMessage());
			return Response.status(404).entity("Could not generate").build();
		}
	}

}
